import { useState } from "react";
import "./App.css";

function App() {
  const [cnpj, setCnpj] = useState("");
  const [dados, setDados] = useState(null);
  const [erro, setErro] = useState("");
  const [loading, setLoading] = useState(false);

  function formatarCNPJ(valor) {
    valor = valor.replace(/\D/g, "");
    return valor
      .replace(/^(\d{2})(\d)/, "$1.$2")
      .replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3")
      .replace(/\.(\d{3})(\d)/, ".$1/$2")
      .replace(/(\d{4})(\d)/, "$1-$2")
      .slice(0, 18);
  }

  function limparMascara(v) {
    return v.replace(/\D/g, "");
  }

  async function buscarCNPJ() {
    setErro("");
    setDados(null);
    setLoading(true);

    const puro = limparMascara(cnpj);

    if (!/^[0-9]{14}$/.test(puro)) {
      setLoading(false);
      setErro("Digite um CNPJ válido (14 números).");
      return;
    }

    try {
      const response = await fetch(
        `https://brasilapi.com.br/api/cnpj/v1/${puro}`
      );

      if (response.status === 404) {
        setLoading(false);
        setErro("CNPJ não encontrado.");
        return;
      }

      if (!response.ok) {
        setLoading(false);
        setErro("Erro ao consultar a API.");
        return;
      }

      const data = await response.json();
      setDados(data);
    } catch (e) {
      setErro("Erro ao conectar à API.");
    }

    setLoading(false);
  }

  return (
    <div className="container">

      <h1>Consulta de CNPJ</h1>

      {/* FORM (ENTER FUNCIONA AQUI) */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          buscarCNPJ();
        }}
      >
        <input
          type="text"
          placeholder="Digite o CNPJ"
          value={cnpj}
          onChange={(e) => setCnpj(formatarCNPJ(e.target.value))}
        />

        <button type="submit" disabled={loading}>
          {loading ? "Buscando..." : "Buscar CNPJ"}
        </button>
      </form>

      {erro && <p className="erro">{erro}</p>}

      {loading && <div className="loader"></div>}

      {dados && (
        <div className="card">

          <h2>📌 Dados Cadastrais</h2>
          <p><strong>CNPJ:</strong> {dados.cnpj}</p>
          <p><strong>Razão Social:</strong> {dados.razao_social}</p>
          <p><strong>Nome Fantasia:</strong> {dados.nome_fantasia}</p>
          <p><strong>Situação:</strong> {dados.descricao_situacao_cadastral}</p>
          <p><strong>Início:</strong> {dados.data_inicio_atividade}</p>

          <hr />

          <h3>📍 Endereço</h3>
          <p><strong>UF:</strong> {dados.uf}</p>
          <p><strong>Município:</strong> {dados.municipio}</p>
          <p><strong>Bairro:</strong> {dados.bairro}</p>
          <p><strong>Logradouro:</strong> {dados.logradouro}</p>
          <p><strong>Número:</strong> {dados.numero}</p>
          <p><strong>CEP:</strong> {dados.cep}</p>

          <hr />

          <h3>📄 CNAE</h3>
          <p>
            <strong>Código:</strong> {dados.cnae_fiscal}<br />
            <strong>Descrição:</strong> {dados.cnae_fiscal_descricao}
          </p>

        </div>
      )}
    </div>
  );
}

export default App;
